import com.employeecard.core.a;
import com.employeecard.core.g;
import com.employeecard.core.j;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;


public class b
{
  g c = new g();
  

  a d;
  

  j e;
  

  @Given("^an employee card with an access level of (\\d+)$")
  public void a(int paramInt)
  {
    this.c.s(paramInt);
  }
  



  @Given("^an access control with the ID (\\d+)$ and an access level set to (\\d+)$")
  public void a(int paramInt1, int paramInt2)
  {
    this.d = new a(paramInt1, paramInt2);
  }
  



  @Given("^an employee card with in use status is (true|false)$")
  public void a(boolean paramBoolean)
  {
    this.c.e(paramBoolean);
  }
  



  @When("^an employee card is set to in use and is used at the access control")
  public void b()
  {
    this.e = this.d.a(this.c);
  }
  



  @Then("^the employee card is allowed access")
  public void b(boolean paramBoolean)
  {
    Assert.assertEquals(this.d.a(this.c), Boolean.valueOf(paramBoolean));
  }
  



  @Then("^the access control displays a message that \"([^\"]*)\"$")
  public void c(String paramString)
  {
    Assert.assertEquals(this.e.Y(), paramString);
  }
  




  @Then("^the access control posts that message in the system log$")
  public void c()
  {
    this.d.C();
  }
}
