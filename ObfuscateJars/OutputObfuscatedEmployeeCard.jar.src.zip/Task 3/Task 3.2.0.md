Question Task 3.2.0:
--------------------

Carl wants to be able to purchase goods through his employee card. 
He goes to a self-service machine at KU Student Canteen and provides her employee card and credit card.
The employee card is successfully deposited with its initial balance and is activated for purchases.
Additionally, a message is posted to the system log.

-> Can you search the source code and identify what is the message posted to the system log?

-> Once you have the answer please open "Task 3.2.1.md"