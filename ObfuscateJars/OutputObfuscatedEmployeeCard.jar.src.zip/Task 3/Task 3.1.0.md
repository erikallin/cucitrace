Question Task 3.1.0:
--------------------

Billy wants to access a location at his work travel card. 
He goes to an access control at his work and shows his employee card

-> What are the criterias to get through an access control and what message is shown when access is granted?

-> Once you have the answer please open "Task 3.1.1.md"
