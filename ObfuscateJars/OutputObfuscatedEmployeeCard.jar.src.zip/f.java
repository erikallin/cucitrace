import com.employeecard.core.g;
import com.employeecard.core.j;
import com.employeecard.core.m;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;




public class f
{
  g c = new g();
  

  com.employeecard.core.f n;
  

  m o;
  

  j p;
  
  j q;
  

  @Given("^an employee card with a balance of (\\d+)$")
  public void d(int paramInt)
  {
    this.c.j(paramInt);
  }
  



  @Given("^a self-service machine for depositing at \"([^\"]*)\"$")
  public void j(String paramString)
  {
    this.n = new com.employeecard.core.f(paramString);
  }
  



  @Given("^an employee card with in use status is (true|false)$")
  public void a(boolean paramBoolean)
  {
    this.c.e(paramBoolean);
  }
  



  @When("^an employee card is set to in use and is deposited with a balance of (\\d+)$")
  public void e(int paramInt)
  {
    this.p = this.n.a(this.c, paramInt);
  }
  



  @Then("^the employee card after a deposit has a new balance (\\d+)$")
  public void f(int paramInt)
  {
    Assert.assertEquals(this.c.u(), paramInt);
  }
  



  @Given("^a self-service machine for withdrawing at \"([^\"]*)\"$")
  public void k(String paramString)
  {
    this.o = new m(paramString);
  }
  



  @When("^an employee card is set to in use and is withdrawn with a balance of (\\d+)$")
  public void g(int paramInt)
  {
    this.q = this.o.c(this.c, paramInt);
  }
  



  @Then("^the employee card after a withdrawal has a new balance (\\d+)$")
  public void h(int paramInt)
  {
    Assert.assertEquals(this.c.u(), paramInt);
  }
  




  @Then("^the depositing self-service machine displays a message that \"([^\"]*)\"$")
  public void l(String paramString)
  {
    Assert.assertEquals(this.p.Y(), paramString);
  }
  




  @Then("^the withdrawing self-service machine displays a message that \"([^\"]*)\"$")
  public void m(String paramString)
  {
    Assert.assertEquals(this.q.Y(), paramString);
  }
  




  @Then("^the depositing self-service machine posts that message in the system log$")
  public void n()
  {
    this.n.R();
  }
  



  @Then("^the withdrawing self-service machine posts that message in the system log$")
  public void o()
  {
    this.o.ag();
  }
}
