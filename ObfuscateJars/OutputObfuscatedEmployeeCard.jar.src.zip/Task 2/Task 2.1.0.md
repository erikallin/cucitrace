Question Task 2.1.0:
--------------------

Jenny inserts her credit card at a self-service machine at KU Student Canteen. 
The self-service machine reads the credit card number and verifies if the credit card is valid. 

-> What are the conditions for Jenny's credit card to be considered as a valid one?

-> Once you have the answer please open "Task 2.1.1.md"