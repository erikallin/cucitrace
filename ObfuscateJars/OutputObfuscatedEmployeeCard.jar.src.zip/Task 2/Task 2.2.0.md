Question Task 2.2.0:
--------------------

Marie inserts her credit card at a self-service machine at DTU Student Canteen 101. 
The self-service machine reads the credit card number and verifies if the credit card is valid. 

-> How is it known that the inserted credit card "378282246310005" is linked to a
company provider? Can you search the source code and locate how this check is performed?

-> Once you have the answer please open "Task 2.2.1.md"
 
