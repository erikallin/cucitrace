Answer Task 2.1.1:
------------------

-> Can you explain verbally and in detail how you found your answer  to "Task 2.1.0.md"??

-> How would you rate the difficulty of this task in the scale of 
	1: Very easy
	2: Easy
	3: Neutral
	4: Difficult
	5: Very difficult 

When you complete your answer CLOSE ALL the tabs in the explorer 

-> Continue to "Task 2.2.0.md"
