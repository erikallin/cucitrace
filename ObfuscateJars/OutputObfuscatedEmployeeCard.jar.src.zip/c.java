import com.creditcard.validation.a;
import com.employeecard.core.g;
import com.employeecard.core.j;
import com.employeecard.core.k;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import java.util.List;
import org.junit.Assert;










public class c
{
  g f;
  a g;
  k h;
  j i;
  
  @Given("^an employee at a self service machine at canteen \"([^\"]*)\"$")
  public void d(String paramString)
  {
    this.h = new k(paramString);
  }
  



  @Given("^his credit card \"([^\"]*)\" was successfully verified by the self service machine$")
  public void e(String paramString)
  {
    this.g = new a(paramString);
    this.g.d(true);
    this.h.a(this.g);
  }
  



  @Given("^his credit card accepts to charge the amount of (\\d+)$")
  public void b(int paramInt)
  {
    this.g.j(paramInt);
  }
  




  @Given("^his credit card declines to charge the amount of (\\d+)$")
  public void c(int paramInt)
  {
    this.g.j(0 - paramInt);
  }
  



  @Given("^an employeeID \"([^\"]*)\" is not registered in the system$")
  public void f(String paramString)
  {
    this.f = new g(paramString);
  }
  



  @When("^activate purchases on an employee card$")
  public void d()
  {
    this.i = this.h.c(this.f);
  }
  




  @Then("^an employee card is registered for purchases$")
  public void e()
  {
    Assert.assertEquals(Boolean.valueOf(this.h.ab().contains(this.f)), Boolean.valueOf(true));
  }
  




  @Then("^the self service machine displays a message that an employee card is activated for purchases$")
  public void f()
  {
    Assert.assertEquals(this.i.Y(), "Employee card was registered for purchases");
  }
  



  @Given("^an employeeID \"([^\"]*)\" is registered in the system$")
  public void g(String paramString)
  {
    this.f = new g(paramString);
    this.h.ab().add(this.f);
  }
  



  @Then("^the self service machine displays a message that an employee card is not registered for purchases because user already registered in the system$")
  public void g()
  {
    Assert.assertEquals(this.i.Y(), "Employee card was registered for purchases");
  }
  



  @Then("^the self service machine displays a message that an employee card is not registered for purchases because credit card was declined$")
  public void h()
  {
    Assert.assertEquals(this.i.Y(), "credit card declined to charge the amount");
  }
  



  @Then("^the self service machine posts that message on the system log$")
  public void i()
  {
    this.h.Z();
  }
}
