import com.employeecard.core.l;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import org.junit.Assert;





public class a
{
  l a;
  String b;
  
  @Given("^a manager wants to setup the system with the log file \"([^\"]*)\"$")
  public void a(String paramString)
  {
    this.b = paramString;
  }
  


  @When("^setup$")
  public void a()
  {
    this.a = new l(this.b);
  }
  



  @When("^the log file \"([^\"]*)\" recording system actions is generated$")
  public void b(String paramString)
  {
    Assert.assertEquals(Boolean.valueOf(this.a.z(paramString)), Boolean.valueOf(true));
  }
}
