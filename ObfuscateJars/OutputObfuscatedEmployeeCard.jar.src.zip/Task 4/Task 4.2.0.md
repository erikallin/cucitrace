Question Task 4.2.0:
--------------------

James manages the employee card system and he wants to see the report of the number 
of employee cards being deposited and withdrawn from in all canteens.

-> How does the employee card system gets the number of deposits
	and withdrawals that occur in all canteens when creating the report?
	
-> Once you have the answer please open "Task 4.2.1.md"