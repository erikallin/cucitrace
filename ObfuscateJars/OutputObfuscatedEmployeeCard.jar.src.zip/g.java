import com.creditcard.validation.a;
import com.employeecard.core.j;
import com.employeecard.core.k;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;









public class g
{
  a r;
  k h;
  j i;
  
  @Given("^a self service machine at canteen \"([^\"]*)\"$")
  public void n(String paramString)
  {
    this.h = new k(paramString);
  }
  




  @Given("^a credit card with number \"([^\"]*)\"$")
  public void o(String paramString)
  {
    this.r = new a(paramString);
  }
  



  @When("^the self service machine validates the credit card$")
  public void p()
  {
    this.i = this.h.b(this.r);
  }
  




  @Then("^the self service machine informs the employee that the provided credit card is valid$")
  public void q()
  {
    Assert.assertEquals(this.i.Y(), "credit card is valid");
  }
  




  @Then("^the self service machine informs the employee that the provided credit card is invalid because it contains characters$")
  public void r()
  {
    Assert.assertEquals(this.i.Y(), "credit card is invalid because it contains characters");
  }
  



  @Then("^the self service machine informs the employee that the provided credit card is invalid because it has too few digits$")
  public void s()
  {
    Assert.assertEquals(this.i.Y(), "credit card is invalid because it has too few digits");
  }
  



  @Then("^the self service machine informs the employee that the provided credit card because it does not belong to a company provider$")
  public void t()
  {
    Assert.assertEquals(this.i.Y(), "credit card is invalid it does not belong to a company provider");
  }
}
