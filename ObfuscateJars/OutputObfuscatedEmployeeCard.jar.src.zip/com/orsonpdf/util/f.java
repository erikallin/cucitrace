package com.orsonpdf.util;












































public enum f
{
  private String aO;
  











































  private f(String paramString1)
  {
    this.aO = paramString1;
  }
  





  public boolean bJ()
  {
    return (this == dg) || (this == dm) || 
      (this == dj) || (this == dp) || 
      (this == ds);
  }
  





  public boolean bK()
  {
    return (this == dh) || (this == dn) || 
      (this == dk) || (this == dq) || 
      (this == dt);
  }
  





  public boolean bL()
  {
    return (this == di) || (this == do) || 
      (this == dl) || (this == dr) || 
      (this == du);
  }
  





  public boolean bM()
  {
    return (this == dg) || (this == dh) || (this == di);
  }
  





  public boolean bN()
  {
    return (this == dj) || (this == dk) || 
      (this == dl);
  }
  





  public boolean bO()
  {
    return (this == dm) || (this == dn) || (this == do);
  }
  





  public boolean bP()
  {
    return (this == dp) || (this == dq) || 
      (this == dr);
  }
  





  public boolean bQ()
  {
    return (this == ds) || (this == dt) || 
      (this == du);
  }
  





  public String az()
  {
    return this.aO;
  }
}
