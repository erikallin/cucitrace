package com.orsonpdf;












public final class x
  extends g
{
  private g[] cE;
  










  private float[] cF;
  










  private float[] cG;
  











  public x(int paramInt, g[] paramArrayOfg, float[] paramArrayOfFloat1, float[] paramArrayOfFloat2)
  {
    super(paramInt, h.aV);
    this.cE = paramArrayOfg;
    this.aK.a("/Functions", paramArrayOfg);
    this.cF = paramArrayOfFloat1;
    this.aK.a("/Bounds", paramArrayOfFloat1);
    this.cG = paramArrayOfFloat2;
    this.aK.a("/Encode", paramArrayOfFloat2);
  }
}
