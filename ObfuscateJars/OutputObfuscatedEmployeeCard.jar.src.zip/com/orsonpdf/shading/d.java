package com.orsonpdf.shading;





























public enum d
{
  private int aX;
  




























  private d(int paramInt1)
  {
    this.aX = paramInt1;
  }
  




  public int aC()
  {
    return this.aX;
  }
}
