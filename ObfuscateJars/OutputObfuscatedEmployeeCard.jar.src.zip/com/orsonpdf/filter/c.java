package com.orsonpdf.filter;

public abstract interface c
{
  public abstract d bz();
  
  public abstract byte[] a(byte[] paramArrayOfByte);
}
