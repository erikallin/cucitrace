package com.orsonpdf.filter;

import com.orsonpdf.util.a;














































public enum d
{
  private String cP;
  
  private d(String paramString1)
  {
    a.a(paramString1, "decode");
    this.cP = paramString1;
  }
  





  public String bC()
  {
    return this.cP;
  }
}
