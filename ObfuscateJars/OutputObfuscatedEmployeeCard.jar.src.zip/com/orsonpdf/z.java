package com.orsonpdf;

abstract interface z {}
