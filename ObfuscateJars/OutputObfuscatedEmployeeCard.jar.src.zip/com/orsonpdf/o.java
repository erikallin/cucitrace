package com.orsonpdf;

import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;









































public class o
  extends GraphicsDevice
{
  private String cd;
  GraphicsConfiguration ce;
  
  public o(String paramString, GraphicsConfiguration paramGraphicsConfiguration)
  {
    this.cd = paramString;
    this.ce = paramGraphicsConfiguration;
  }
  





  public int bj()
  {
    return 1;
  }
  





  public String bk()
  {
    return this.cd;
  }
  





  public GraphicsConfiguration[] bl()
  {
    return new GraphicsConfiguration[] { bm() };
  }
  





  public GraphicsConfiguration bm()
  {
    return this.ce;
  }
}
