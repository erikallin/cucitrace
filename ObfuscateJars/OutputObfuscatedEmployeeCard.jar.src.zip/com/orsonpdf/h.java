package com.orsonpdf;


























public enum h
{
  private int aX;
  
























  private h(int paramInt1)
  {
    this.aX = paramInt1;
  }
  




  public int aC()
  {
    return this.aX;
  }
}
