package com.orsonpdf;














public class i
  extends c
{
  private float aZ;
  












  private float ba;
  













  public i(int paramInt)
  {
    super(paramInt, "/ExtGState");
  }
  




  public float aD()
  {
    return this.aZ;
  }
  




  public void a(float paramFloat)
  {
    this.aZ = paramFloat;
    this.aK.a("/CA", Float.valueOf(paramFloat));
  }
  





  public float aE()
  {
    return this.ba;
  }
  





  public void b(float paramFloat)
  {
    this.ba = paramFloat;
    this.aK.a("/ca", Float.valueOf(paramFloat));
  }
}
