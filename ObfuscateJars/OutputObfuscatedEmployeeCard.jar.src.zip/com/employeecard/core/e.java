package com.employeecard.core;

public class e
{
  public static final String S = "employee card already in use";
  public static final String T = "employee card account balance is too low to be withdrawn from";
  public static final String U = "employee card account is successfully deposited";
  public static final String V = "employee card account have access through this access control";
  public static final String W = "employee card account does not have access through this access control";
  public static final String X = "employee card already in use";
  public static final String Y = "employee card account is not withdrawn from";
  public static final String Z = "employee card account is successfully withdrawn from";
  public static final String aa = "credit card is invalid it does not belong to a company provider";
  public static final String ab = "credit card is invalid because it has too few digits";
  public static final String ac = "credit card is invalid because it contains characters";
  public static final String ad = "credit card declined to charge the amount";
  public static final int ae = 0;
  public static final String af = "repCanteenStatistics.pdf";
  public static final String ag = "repNameList.txt";
  public static final String ah = "repAccessControlList.txt";
  public static final String ai = "Employee card was not registered for purchases because user already registered in the system";
  public static final String aj = "Employee card was registered for purchases";
  public static final String ak = "credit card is valid";
  public static final String al = "credit card accepted to charge the amount";
}
