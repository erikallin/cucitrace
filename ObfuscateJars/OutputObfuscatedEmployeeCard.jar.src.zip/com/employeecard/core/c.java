package com.employeecard.core;



public class c
{
  private f M;
  

  private m N;
  

  private int O;
  

  private int P;
  

  private k h;
  
  private String Q;
  

  public c(String paramString)
  {
    this.Q = paramString;
  }
  



  public f I()
  {
    return this.M;
  }
  



  public m J()
  {
    return this.N;
  }
  



  public int K()
  {
    return this.P;
  }
  



  public int L()
  {
    return this.O;
  }
  



  public k M()
  {
    return this.h;
  }
  



  public String N()
  {
    return this.Q;
  }
  



  public void a(f paramf)
  {
    this.M = paramf;
  }
  



  public void a(m paramm)
  {
    this.N = paramm;
  }
  



  public void o(int paramInt)
  {
    this.P = paramInt;
  }
  



  public void p(int paramInt)
  {
    this.O = paramInt;
  }
  



  public void a(k paramk)
  {
    this.h = paramk;
  }
  



  public void u(String paramString)
  {
    this.Q = paramString;
  }
}
