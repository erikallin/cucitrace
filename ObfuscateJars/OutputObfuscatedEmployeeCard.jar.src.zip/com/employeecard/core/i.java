package com.employeecard.core;

public class i {
  public static l aq = new l();
}
