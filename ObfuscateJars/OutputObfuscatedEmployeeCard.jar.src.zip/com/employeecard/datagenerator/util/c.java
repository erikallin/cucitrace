package com.employeecard.datagenerator.util;

import com.employeecard.core.g;
import java.util.ArrayList;
import java.util.List;

public class c
{
  private static final String[] aG = { "1012921234", "1012921234", "1012921234", "1012921234", "1012921234", 
    "1012921234", "1012921234", "1012921234", "1012921234", "1012921234", "1012921234", "1012921234" };
  
  private static int al() {
    return d.b(150, 312);
  }
  
  private static int am() {
    return d.b(0, 2);
  }
  
  private static String an() {
    return (String)d.a(aG);
  }
  





  public List<g> u(int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    
    for (int i = 0; i < paramInt; i++) {
      localArrayList.add(ao());
    }
    
    return localArrayList;
  }
  
  private g ao() {
    return new g(an(), al(), am(), false);
  }
}
