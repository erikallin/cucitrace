package com.creditcard.validation;





public enum b
{
  private String E;
  


  private String F;
  



  public static b q(String paramString)
  {
    b[] arrayOfb;
    


    int j = (arrayOfb = values()).length; for (int i = 0; i < j; i++) { b localb = arrayOfb[i];
      if (localb.s(paramString)) {
        return localb;
      }
    }
    return null;
  }
  






  public static b r(String paramString)
  {
    b[] arrayOfb;
    





    int j = (arrayOfb = values()).length; for (int i = 0; i < j; i++) { b localb = arrayOfb[i];
      if (localb.B().equals(paramString)) {
        return localb;
      }
    }
    return null;
  }
  









  private b(String paramString2, String paramString3)
  {
    this.F = paramString2;
    this.E = paramString3;
  }
  



  public String B()
  {
    return this.E;
  }
  



  public boolean s(String paramString)
  {
    return paramString.matches(this.F);
  }
}
