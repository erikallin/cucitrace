Question Task 1.1.0:
--------------------

John is at a self-service machine in the canteen SDU Student Canteen and his employee card has a balance of 100.

-> What does the self-service machine display when John deposits a balance of 100 to his employee card successfully in SDU Student Canteen?

-> Once you have the answer please open "Task 1.1.1.md"