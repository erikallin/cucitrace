Question Task 1.2.0:
------------------

Bob purchases a sandwich from DTU Student Canteen 341 by using his employee card.
 
-> When Bob uses his employee card, he receives a message that "employee card account is successfully withdrawn from". Can you search the source code and locate what is the internal response code used?  

-> Once you have the answer please open "Task 1.2.1.md"
