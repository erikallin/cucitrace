import com.employeecard.core.c;
import com.employeecard.core.h;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;











public class d
{
  com.employeecard.core.d j;
  c k;
  String l;
  h m;
  
  @Given("^the manager wants to know the number of employee cards being deposited and withdrawn from in all canteens$")
  public void j()
  {
    this.j = new com.employeecard.core.d();
  }
  




  @When("^he generates a canteen statistics report$")
  public void k()
  {
    this.j.O();
  }
  



  @Then("^the system produces a pdf report named as \"([^\"]*)\"$")
  public void h(String paramString)
  {
    Assert.assertEquals(Boolean.valueOf(this.j.t(paramString)), Boolean.valueOf(true));
  }
  



  @Given("^the manager wants to see a list with the names of employees registered in the system$")
  public void l()
  {
    this.m = new h();
  }
  



  @When("^he generates an employee list$")
  public void m()
  {
    this.m.V();
  }
  



  @Then("^the system produces a text file named as \"([^\"]*)\" which contains the employee list$")
  public void i(String paramString)
  {
    Assert.assertEquals(Boolean.valueOf(this.m.t(paramString)), Boolean.valueOf(true));
  }
}
