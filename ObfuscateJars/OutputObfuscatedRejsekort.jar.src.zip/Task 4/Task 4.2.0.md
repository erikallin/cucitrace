Question Task 4.2.0:
--------------------

James manages the Travel card system and he wants to see the report of the number 
of travel cards being checked-in and checked out at all stations.

-> How does the travel card system gets the number of check-ins
	and check-outs that occur in all stations when creating the report?
	
-> Once you have the answer please open "Task 4.2.1.md"