package com.creditcard.validation;





public enum b
{
  private String F;
  


  private String G;
  



  public static b r(String paramString)
  {
    b[] arrayOfb;
    


    int j = (arrayOfb = values()).length; for (int i = 0; i < j; i++) { b localb = arrayOfb[i];
      if (localb.t(paramString)) {
        return localb;
      }
    }
    return null;
  }
  






  public static b s(String paramString)
  {
    b[] arrayOfb;
    





    int j = (arrayOfb = values()).length; for (int i = 0; i < j; i++) { b localb = arrayOfb[i];
      if (localb.E().equals(paramString)) {
        return localb;
      }
    }
    return null;
  }
  









  private b(String paramString2, String paramString3)
  {
    this.G = paramString2;
    this.F = paramString3;
  }
  



  public String E()
  {
    return this.F;
  }
  



  public boolean t(String paramString)
  {
    return paramString.matches(this.G);
  }
}
