package com.orsonpdf.filter;

public abstract interface c
{
  public abstract d aP();
  
  public abstract byte[] a(byte[] paramArrayOfByte);
}
