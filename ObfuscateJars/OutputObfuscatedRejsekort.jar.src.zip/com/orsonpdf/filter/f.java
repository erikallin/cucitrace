package com.orsonpdf.filter;

abstract interface f {}
