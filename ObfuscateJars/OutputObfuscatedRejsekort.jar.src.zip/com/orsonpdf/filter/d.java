package com.orsonpdf.filter;

import com.orsonpdf.util.a;














































public enum d
{
  private String bP;
  
  private d(String paramString1)
  {
    a.a(paramString1, "decode");
    this.bP = paramString1;
  }
  





  public String aS()
  {
    return this.bP;
  }
}
