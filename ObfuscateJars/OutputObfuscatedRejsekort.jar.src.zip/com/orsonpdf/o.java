package com.orsonpdf;

import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;









































public class o
  extends GraphicsDevice
{
  private String bd;
  GraphicsConfiguration be;
  
  public o(String paramString, GraphicsConfiguration paramGraphicsConfiguration)
  {
    this.bd = paramString;
    this.be = paramGraphicsConfiguration;
  }
  





  public int az()
  {
    return 1;
  }
  





  public String aA()
  {
    return this.bd;
  }
  





  public GraphicsConfiguration[] aB()
  {
    return new GraphicsConfiguration[] { aC() };
  }
  





  public GraphicsConfiguration aC()
  {
    return this.be;
  }
}
