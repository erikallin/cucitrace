package com.orsonpdf;

import com.orsonpdf.util.a;











































public class c
  extends r
{
  protected b K;
  
  c(int paramInt, String paramString)
  {
    super(paramInt);
    this.K = new b(paramString);
  }
  






  public void a(String paramString, Object paramObject)
  {
    a.a(paramObject, "value");
    this.K.a("/" + paramString, paramObject);
  }
  






  public Object v(String paramString)
  {
    return this.K.v("/" + paramString);
  }
  






  public byte[] K()
  {
    return this.K.I();
  }
}
