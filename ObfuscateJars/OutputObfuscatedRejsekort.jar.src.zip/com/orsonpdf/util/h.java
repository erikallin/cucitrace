package com.orsonpdf.util;

abstract interface h {}
