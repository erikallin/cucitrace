package com.orsonpdf.util;












































public enum f
{
  private String O;
  











































  private f(String paramString1)
  {
    this.O = paramString1;
  }
  





  public boolean aZ()
  {
    return (this == cg) || (this == cm) || 
      (this == cj) || (this == cp) || 
      (this == cs);
  }
  





  public boolean ba()
  {
    return (this == ch) || (this == cn) || 
      (this == ck) || (this == cq) || 
      (this == ct);
  }
  





  public boolean bb()
  {
    return (this == ci) || (this == co) || 
      (this == cl) || (this == cr) || 
      (this == cu);
  }
  





  public boolean bc()
  {
    return (this == cg) || (this == ch) || (this == ci);
  }
  





  public boolean bd()
  {
    return (this == cj) || (this == ck) || 
      (this == cl);
  }
  





  public boolean be()
  {
    return (this == cm) || (this == cn) || (this == co);
  }
  





  public boolean bf()
  {
    return (this == cp) || (this == cq) || 
      (this == cr);
  }
  





  public boolean bg()
  {
    return (this == cs) || (this == ct) || 
      (this == cu);
  }
  





  public String P()
  {
    return this.O;
  }
}
