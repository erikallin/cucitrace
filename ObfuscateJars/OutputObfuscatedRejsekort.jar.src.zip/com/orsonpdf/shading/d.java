package com.orsonpdf.shading;





























public enum d
{
  private int X;
  




























  private d(int paramInt1)
  {
    this.X = paramInt1;
  }
  




  public int S()
  {
    return this.X;
  }
}
