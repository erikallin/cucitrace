package com.orsonpdf.shading;

abstract interface e {}
