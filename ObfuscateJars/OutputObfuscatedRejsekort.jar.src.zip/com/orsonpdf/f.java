package com.orsonpdf;

import java.awt.Font;

public abstract interface f
{
  public abstract String a(Font paramFont);
}
