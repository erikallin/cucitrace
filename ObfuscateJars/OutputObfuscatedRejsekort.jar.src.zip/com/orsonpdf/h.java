package com.orsonpdf;


























public enum h
{
  private int X;
  
























  private h(int paramInt1)
  {
    this.X = paramInt1;
  }
  




  public int S()
  {
    return this.X;
  }
}
