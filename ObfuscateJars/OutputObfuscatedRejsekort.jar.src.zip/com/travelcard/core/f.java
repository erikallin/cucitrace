package com.travelcard.core;



public class f
{
  private int cY;
  
  private String cZ;
  
  private String da;
  

  public f(int paramInt, String paramString)
  {
    this.cY = paramInt;
    this.da = paramString;
  }
  



  public int br()
  {
    return this.cY;
  }
  



  public String bs()
  {
    return this.cZ;
  }
  



  public String bt()
  {
    return this.da;
  }
  



  public void u(int paramInt)
  {
    this.cY = paramInt;
  }
  



  public void E(String paramString)
  {
    this.da = paramString;
  }
}
