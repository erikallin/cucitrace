package com.travelcard.core;



public class g
{
  private a db;
  

  private b dc;
  

  private int cw;
  

  private int dd;
  

  private e q;
  
  private String cy;
  

  public g(String paramString)
  {
    this.cy = paramString;
  }
  



  public a bu()
  {
    return this.db;
  }
  



  public b bv()
  {
    return this.dc;
  }
  



  public int bj()
  {
    return this.cw;
  }
  



  public int bw()
  {
    return this.dd;
  }
  



  public e bx()
  {
    return this.q;
  }
  



  public String bi()
  {
    return this.cy;
  }
  



  public void a(a parama)
  {
    this.db = parama;
  }
  



  public void a(b paramb)
  {
    this.dc = paramb;
  }
  



  public void s(int paramInt)
  {
    this.cw = paramInt;
  }
  



  public void v(int paramInt)
  {
    this.dd = paramInt;
  }
  



  public void a(e parame)
  {
    this.q = parame;
  }
  



  public void B(String paramString)
  {
    this.cy = paramString;
  }
}
