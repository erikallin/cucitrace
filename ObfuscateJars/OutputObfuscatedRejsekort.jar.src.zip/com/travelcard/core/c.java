package com.travelcard.core;

public class c
{
  public static final String cB = "the travel card is already checked-in";
  public static final String cC = "the travel card balance is too low";
  public static final String cD = "the travel card is checked-in";
  public static final String cE = "the travel card is not checked-in";
  public static final String cF = "the travel card is successfully checked-out";
  public static final String cG = "credit card is invalid it does not belong to a company provider";
  public static final String cH = "credit card is invalid because it has too few digits";
  public static final String cI = "credit card is invalid because it contains characters";
  public static final String cJ = "credit card declined to charge the amount";
  public static final int cK = 0;
  public static final String cL = "Travel card failed to reload";
  public static final String cM = "Travel card was reloaded successfully";
  public static final String cN = "repStationStatistics.pdf";
  public static final String cO = "repNameList.txt";
  public static final String cP = "Travel card was not created because user already registered in the system";
  public static final String cQ = "Travel card was issued";
  public static final String cR = "credit card is valid";
  public static final String cS = "credit card accepted to charge the amount";
}
