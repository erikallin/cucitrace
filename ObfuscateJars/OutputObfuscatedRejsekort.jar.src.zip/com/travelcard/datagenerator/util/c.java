package com.travelcard.datagenerator.util;

import java.util.Random;




public class c
{
  private static final Random jdField_do = new Random();
  
  public static int c(int paramInt1, int paramInt2)
  {
    return paramInt1 + (int)Math.round(do.nextDouble() * (paramInt2 - paramInt1));
  }
  
  public static <T> T a(T[] paramArrayOfT) {
    return paramArrayOfT[c(0, paramArrayOfT.length - 1)];
  }
}
