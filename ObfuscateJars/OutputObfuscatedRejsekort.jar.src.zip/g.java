import com.creditcard.validation.a;
import com.travelcard.core.e;
import com.travelcard.core.f;
import com.travelcard.core.j;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;









public class g
{
  private a m;
  private e r;
  private f o;
  j s;
  
  @Given("^a travel card user at a reload kiosk at station \"([^\"]*)\"$")
  public void o(String paramString)
  {
    this.r = new e(paramString);
  }
  



  @Given("^his travel card has a balance of (\\d+)$")
  public void e(int paramInt)
  {
    this.s = new j(paramInt);
  }
  



  @Given("^his credit card \"([^\"]*)\" was successfully verified by the reload kiosk$")
  public void p(String paramString)
  {
    this.m = new a(paramString);
    this.m.c(true);
    this.r.a(this.m);
  }
  



  @Given("^his credit card accepts to charge (\\d+)$")
  public void f(int paramInt)
  {
    this.m.k(paramInt);
  }
  



  @When("^the travel card user reloads the travel card with (\\d+)$")
  public void g(int paramInt)
  {
    this.o = this.r.a(this.s, paramInt);
  }
  



  @Then("^the travel card after reload has a new balance (\\d+)$")
  public void h(int paramInt)
  {
    Assert.assertEquals(this.s.x(), paramInt);
  }
  




  @Then("^the credit card is charged with (\\d+)$")
  public void i(int paramInt)
  {
    Assert.assertEquals(Boolean.valueOf(this.m.B()), Boolean.valueOf(true));
  }
  



  @Then("^the reload kiosk displays a message that the travel card was reloaded successfully$")
  public void u()
  {
    Assert.assertEquals(this.o.bt(), "Travel card was reloaded successfully");
  }
  



  @Then("^the reload kiosk displays a message that the travel card failed to reload$")
  public void v()
  {
    Assert.assertEquals(this.o.bt(), "Travel card failed to reload");
  }
  



  @Given("^the reload kiosk posts that message on the system log$")
  public void w()
  {
    this.r.bn();
  }
}
