import com.travelcard.core.g;
import com.travelcard.core.h;
import com.travelcard.core.k;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;









public class c
{
  h h;
  g i;
  String j;
  k k;
  
  @Given("^the manager wants to know the number of travel cards being checked-in and checked-out in all stations$")
  public void f()
  {
    this.h = new h();
  }
  




  @When("^he generates a station statistics report$")
  public void g()
  {
    this.h.by();
  }
  



  @Then("^the system produces a pdf report named as \"([^\"]*)\"$")
  public void g(String paramString)
  {
    Assert.assertEquals(Boolean.valueOf(this.h.F(paramString)), Boolean.valueOf(true));
  }
  



  @Given("^the manager wants to see a list with the names of users registered in the system$")
  public void h()
  {
    this.k = new k();
  }
  



  @When("^he generates a name list$")
  public void i()
  {
    this.k.bG();
  }
  



  @Then("^the system produces a text file named as \"([^\"]*)\" which contains the name list$")
  public void h(String paramString)
  {
    Assert.assertEquals(Boolean.valueOf(this.k.F(paramString)), Boolean.valueOf(true));
  }
}
