import com.travelcard.core.a;
import com.travelcard.core.f;
import com.travelcard.core.j;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;




public class b
{
  j c = new j();
  

  a d;
  

  com.travelcard.core.b e;
  

  f f;
  
  f g;
  

  @Given("^a travel card with a balance of (\\d+)$")
  public void a(int paramInt)
  {
    this.c.k(paramInt);
  }
  



  @Given("^a check-in automaton at \"([^\"]*)\"$")
  public void c(String paramString)
  {
    this.d = new a(paramString);
  }
  



  @Given("^a travel card with check-in status is (true|false)$")
  public void a(boolean paramBoolean)
  {
    this.c.e(paramBoolean);
  }
  



  @When("^Check-in$")
  public void b()
  {
    this.f = this.d.a(this.c);
  }
  



  @Given("^a check-out automaton at \"([^\"]*)\"$")
  public void d(String paramString)
  {
    this.e = new com.travelcard.core.b(paramString);
  }
  



  @When("^a travel card check-out$")
  public void c()
  {
    this.g = this.e.c(this.c);
  }
  



  @Then("^the travel card after check-out has a new balance (\\d+)$")
  public void b(int paramInt)
  {
    Assert.assertEquals(this.c.x(), paramInt);
  }
  




  @Then("^the check-in automaton displays a message that \"([^\"]*)\"$")
  public void e(String paramString)
  {
    Assert.assertEquals(this.f.bt(), paramString);
  }
  




  @Then("^the check-out automaton displays a message that \"([^\"]*)\"$")
  public void f(String paramString)
  {
    Assert.assertEquals(this.g.bt(), paramString);
  }
  




  @Then("^the check-in automaton posts that message in the system log$")
  public void d()
  {
    this.d.bh();
  }
  



  @Then("^the check-out automaton posts a successful message on the system log$")
  public void e()
  {
    this.e.bk();
  }
}
