import com.creditcard.validation.a;
import com.travelcard.core.e;
import com.travelcard.core.f;
import com.travelcard.core.j;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import java.util.List;
import org.junit.Assert;










public class d
{
  j l;
  a m;
  e n;
  f o;
  
  @Given("^a customer at a registration kiosk at station \"([^\"]*)\"$")
  public void i(String paramString)
  {
    this.n = new e(paramString);
  }
  



  @Given("^his credit card \"([^\"]*)\" was successfully verified by the registration kiosk$")
  public void j(String paramString)
  {
    this.m = new a(paramString);
    this.m.c(true);
    this.n.a(this.m);
  }
  



  @Given("^his credit card accepts to charge the amount of (\\d+)$")
  public void c(int paramInt)
  {
    this.m.k(paramInt);
  }
  




  @Given("^his credit card declines to charge the amount of (\\d+)$")
  public void d(int paramInt)
  {
    this.m.k(0 - paramInt);
  }
  



  @Given("^a userID number \"([^\"]*)\" is not registered in the system$")
  public void k(String paramString)
  {
    this.l = new j(paramString);
  }
  



  @When("^issue a travel card$")
  public void j()
  {
    this.o = this.n.e(this.l);
  }
  




  @Then("^a travel card user is registered$")
  public void k()
  {
    Assert.assertEquals(Boolean.valueOf(this.n.bp().contains(this.l)), Boolean.valueOf(true));
  }
  




  @Then("^the registration kiosk displays a message that a travel card is issued$")
  public void l()
  {
    Assert.assertEquals(this.o.bt(), "Travel card was issued");
  }
  



  @Given("^a userID number \"([^\"]*)\" is registered in the system$")
  public void l(String paramString)
  {
    this.l = new j(paramString);
    this.n.bp().add(this.l);
  }
  



  @Then("^the registration kiosk displays a message that a travel card not issued because user already registered in the system$")
  public void m()
  {
    Assert.assertEquals(this.o.bt(), "Travel card was not created because user already registered in the system");
  }
  



  @Then("^the registration kiosk displays a message that a travel card not issued because credit card was declined$")
  public void n()
  {
    Assert.assertEquals(this.o.bt(), "credit card declined to charge the amount");
  }
  



  @Then("^the registration kiosk posts that message on the system log$")
  public void o()
  {
    this.n.bm();
  }
}
