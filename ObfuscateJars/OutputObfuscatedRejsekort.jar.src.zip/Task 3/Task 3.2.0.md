Question Task 3.2.0:
--------------------

Carla wants to purchase a travel card. 
She goes to a kiosk at Copenhagen Airport and provides her userID and credit card. The travel card is successfully issued and a message is posted to the system log.

->  Can you search the source code and identify what is the message posted to the system log?

-> Once you have the answer please open "Task 3.2.1.md"