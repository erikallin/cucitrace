Question Task 3.1.0:
--------------------

Maria wants to reload her travel card. 
She goes to a kiosk at Norreport St and provides her travel card and her credit card

-> What are the criteria to reload a travel card?

-> Once you have the answer please open "Task 3.1.1.md"
