Question Task 2.1.0:
--------------------

Jennifer inserts her credit card at a kiosk at Norreport St. 
The kiosk reads the credit card number and verifies if the credit card is valid. 

-> What are the conditions for Jennifer's credit card to be considered as a valid one?

-> Once you have the answer please open "Task 2.1.1.md"