Question Task 2.2.0:
--------------------

Jennifer inserts her credit card at a kiosk at Norreport St. 
The kiosk reads the credit card number and verifies if the credit card is valid. 

-> How is it known that the inserted credit card "378282246310005" is linked to a
company provider? Can you search the source code and locate how this check is performed?

-> Once you have the answer please open "Task 2.2.1.md"
 
