Question Task 1.1.0:
--------------------

Joe is travelling from Norreport St and his travel card has a balance of 100.

-> What does the check-in automaton display when Joe checks-in his travel card successfully at Norreport St?

-> Once you have the answer please open "Task 1.1.1.md"