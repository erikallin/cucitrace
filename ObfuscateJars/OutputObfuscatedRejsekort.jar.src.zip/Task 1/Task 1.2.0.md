Question Task 1.2.0:
------------------

Joe gets off at Sydhavn St and he checks-out his travel card.
 
-> When Joe checks-out his travel card, he receives a message that "travel card is successfully checked-out". Can you search the source code and locate what is the internal response code used?  

-> Once you have the answer please open "Task 1.2.1.md"
