import com.creditcard.validation.a;
import com.travelcard.core.f;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;










public class e
{
  a p;
  com.travelcard.core.e q;
  f o;
  
  @Given("^a kiosk at station \"([^\"]*)\"$")
  public void m(String paramString)
  {
    this.q = new com.travelcard.core.e(paramString);
  }
  




  @Given("^a credit card with number \"([^\"]*)\"$")
  public void n(String paramString)
  {
    this.p = new a(paramString);
  }
  



  @When("^the kiosk verifies the credit card$")
  public void p()
  {
    this.o = this.q.b(this.p);
  }
  




  @Then("^the kiosk informs the user that the provided credit card is valid$")
  public void q()
  {
    Assert.assertEquals(this.o.bt(), "credit card is valid");
  }
  




  @Then("^the kiosk informs the user that the provided credit card is invalid because it contains characters$")
  public void r()
  {
    Assert.assertEquals(this.o.bt(), "credit card is invalid because it contains characters");
  }
  



  @Then("^the kiosk informs the user that the provided credit card is invalid because it has too few digits$")
  public void s()
  {
    Assert.assertEquals(this.o.bt(), "credit card is invalid because it has too few digits");
  }
  



  @Then("^the kiosk informs the user that the provided credit card because it does not belong to a company provider$")
  public void t()
  {
    Assert.assertEquals(this.o.bt(), "credit card is invalid it does not belong to a company provider");
  }
}
