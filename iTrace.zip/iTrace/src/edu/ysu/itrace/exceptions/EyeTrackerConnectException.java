package edu.ysu.itrace.exceptions;

public class EyeTrackerConnectException extends Exception {
}
