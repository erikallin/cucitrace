package edu.ysu.itrace.exceptions;

public class CalibrationException extends Exception {
    public CalibrationException() {
        super();
    }

    public CalibrationException(String message) {
        super(message);
    }
}
